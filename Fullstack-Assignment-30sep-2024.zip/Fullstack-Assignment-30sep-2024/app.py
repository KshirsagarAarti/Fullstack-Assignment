from flask import Flask, request, jsonify
from flask_pymongo import PyMongo
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)

app.config["MONGO_URI"] = "mongodb://localhost:27017/agent"  
mongo = PyMongo(app)

app.config["JWT_SECRET_KEY"] = "secret123" 
jwt = JWTManager(app)

# User Registration
@app.route('/register', methods=['POST'])
def register():
    username = request.json.get('username')
    password = request.json.get('password')
    hashed_password = generate_password_hash(password)

    mongo.db.users.insert_one({
        "username": username,
        "password": hashed_password
    })
    return jsonify(message="User registered successfully"), 201

# User Login
@app.route('/login', methods=['POST'])
def login():
    username = request.json.get('username')
    password = request.json.get('password')
    user = mongo.db.users.find_one({"username": username})

    if user and check_password_hash(user["password"], password):
        access_token = create_access_token(identity=str(user["_id"]))
        return jsonify(access_token=access_token), 200
    return jsonify(message="Bad username or password"), 401

# Agent Purchase
@app.route('/api/agents/purchase', methods=['POST'])
@jwt_required()
def purchase_agent():
    user_id = get_jwt_identity()
    agent_id = str(mongo.db.agents.insert_one({"user_id": user_id, "status": "Offline", "supported_brands": []}).inserted_id)
    return jsonify(agent_id=agent_id), 201

# Get Agents
@app.route('/api/agents', methods=['GET'])
@jwt_required()
def get_agents():
    user_id = get_jwt_identity()
    agents = mongo.db.agents.find({"user_id": user_id})
    return jsonify([{"_id": str(agent["_id"]), "status": agent["status"], "supported_brands": agent["supported_brands"]} for agent in agents]), 200

# Update Agent Status
@app.route('/api/agents/update_status', methods=['POST'])
def update_status():
    agent_data = request.json
    mongo.db.agents.update_one({"_id": agent_data["agent_id"]}, {"$set": {"status": agent_data["status"]}})
    return jsonify(message="Status updated successfully"), 200

# Configure Agent
@app.route('/api/agents/<agent_id>/configure', methods=['PUT'])
@jwt_required()
def configure_agent(agent_id):
    user_id = get_jwt_identity()
    supported_brands = request.json.get('supported_brands')
    mongo.db.agents.update_one({"_id": agent_id, "user_id": user_id}, {"$set": {"supported_brands": supported_brands}})
    return jsonify(message="Agent configuration updated"), 200

if __name__ == '__main__':
    app.run(debug=True)
