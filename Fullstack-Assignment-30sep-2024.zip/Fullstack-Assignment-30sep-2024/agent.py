import requests
import time

AGENT_ID = '1234'  
BASE_URL = 'http://localhost:5000' 

def send_status_update():
    while True:
        status = {'agent_id': AGENT_ID, 'status': 'Active'}  
        response = requests.post(f'{BASE_URL}/api/agents/update_status', json=status)
        print('Status update sent:', response.json())
        time.sleep(60) 

if __name__ == '__main__':
    send_status_update()
